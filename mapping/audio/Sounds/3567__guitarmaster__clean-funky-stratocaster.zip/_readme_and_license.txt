Sound pack downloaded from Freesound.org
----------------------------------------

This pack of sounds contains sounds by guitarmaster ( http://www.freesound.org/people/guitarmaster/  )
You can find this pack online at: http://www.freesound.org/people/guitarmaster/packs/3567/


License details
---------------

Sampling+: http://creativecommons.org/licenses/sampling+/1.0/
Creative Commons 0: http://creativecommons.org/publicdomain/zero/1.0/
Attribution: http://creativecommons.org/licenses/by/3.0/
Attribution Noncommercial: http://creativecommons.org/licenses/by-nc/3.0/


Sounds in this pack
-------------------

  * 56132__guitarmaster__G_sharp_Note_mute.wav
    * url: http://www.freesound.org/people/guitarmaster/sounds/56132/
    * license: Sampling+
  * 56131__guitarmaster__G_sharp_Note.wav
    * url: http://www.freesound.org/people/guitarmaster/sounds/56131/
    * license: Sampling+
  * 56130__guitarmaster__G_sharp_Low_Note_mute.wav
    * url: http://www.freesound.org/people/guitarmaster/sounds/56130/
    * license: Sampling+
  * 56129__guitarmaster__G_sharp_Low_Note.wav
    * url: http://www.freesound.org/people/guitarmaster/sounds/56129/
    * license: Sampling+
  * 56128__guitarmaster__G_Note_mute.wav
    * url: http://www.freesound.org/people/guitarmaster/sounds/56128/
    * license: Sampling+
  * 56127__guitarmaster__G_Note.wav
    * url: http://www.freesound.org/people/guitarmaster/sounds/56127/
    * license: Sampling+
  * 56126__guitarmaster__G_Low_Note_mute.wav
    * url: http://www.freesound.org/people/guitarmaster/sounds/56126/
    * license: Sampling+
  * 56125__guitarmaster__G_Low_Note.wav
    * url: http://www.freesound.org/people/guitarmaster/sounds/56125/
    * license: Sampling+
  * 56124__guitarmaster__F_sharp_Note_mute.wav
    * url: http://www.freesound.org/people/guitarmaster/sounds/56124/
    * license: Sampling+
  * 56123__guitarmaster__F_sharp_Note.wav
    * url: http://www.freesound.org/people/guitarmaster/sounds/56123/
    * license: Sampling+
  * 56122__guitarmaster__F_Note_mute.wav
    * url: http://www.freesound.org/people/guitarmaster/sounds/56122/
    * license: Sampling+
  * 56121__guitarmaster__F_Note.wav
    * url: http://www.freesound.org/people/guitarmaster/sounds/56121/
    * license: Sampling+
  * 56120__guitarmaster__E_Note_mute.wav
    * url: http://www.freesound.org/people/guitarmaster/sounds/56120/
    * license: Sampling+
  * 56119__guitarmaster__E_Note.wav
    * url: http://www.freesound.org/people/guitarmaster/sounds/56119/
    * license: Sampling+
  * 56118__guitarmaster__D_sharp_Note_mute.wav
    * url: http://www.freesound.org/people/guitarmaster/sounds/56118/
    * license: Sampling+
  * 56117__guitarmaster__D_sharp_Note.wav
    * url: http://www.freesound.org/people/guitarmaster/sounds/56117/
    * license: Sampling+
  * 56116__guitarmaster__D_Note_mute.wav
    * url: http://www.freesound.org/people/guitarmaster/sounds/56116/
    * license: Sampling+
  * 56115__guitarmaster__D_Note.wav
    * url: http://www.freesound.org/people/guitarmaster/sounds/56115/
    * license: Sampling+
  * 56114__guitarmaster__C_sharp_Note_mute.wav
    * url: http://www.freesound.org/people/guitarmaster/sounds/56114/
    * license: Sampling+
  * 56113__guitarmaster__C_sharp_Note.wav
    * url: http://www.freesound.org/people/guitarmaster/sounds/56113/
    * license: Sampling+
  * 56112__guitarmaster__C_Note_mute.wav
    * url: http://www.freesound.org/people/guitarmaster/sounds/56112/
    * license: Sampling+
  * 56111__guitarmaster__C_Note.wav
    * url: http://www.freesound.org/people/guitarmaster/sounds/56111/
    * license: Sampling+
  * 56110__guitarmaster__B_Low_Note_mute.wav
    * url: http://www.freesound.org/people/guitarmaster/sounds/56110/
    * license: Sampling+
  * 56109__guitarmaster__B_Low_Note.wav
    * url: http://www.freesound.org/people/guitarmaster/sounds/56109/
    * license: Sampling+
  * 56108__guitarmaster__A_sharp_Low_Note_mute.wav
    * url: http://www.freesound.org/people/guitarmaster/sounds/56108/
    * license: Sampling+
  * 56106__guitarmaster__A_Note_mute.wav
    * url: http://www.freesound.org/people/guitarmaster/sounds/56106/
    * license: Sampling+
  * 56107__guitarmaster__A_sharp_Low_Note.wav
    * url: http://www.freesound.org/people/guitarmaster/sounds/56107/
    * license: Sampling+
  * 56105__guitarmaster__A_Note.wav
    * url: http://www.freesound.org/people/guitarmaster/sounds/56105/
    * license: Sampling+
  * 56104__guitarmaster__A_Low_Note_mute.wav
    * url: http://www.freesound.org/people/guitarmaster/sounds/56104/
    * license: Sampling+
  * 56103__guitarmaster__A_Low_Note.wav
    * url: http://www.freesound.org/people/guitarmaster/sounds/56103/
    * license: Sampling+

