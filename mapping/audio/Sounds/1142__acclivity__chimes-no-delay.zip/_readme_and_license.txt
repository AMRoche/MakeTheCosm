Sound pack downloaded from Freesound.org
----------------------------------------

This pack of sounds contains sounds by acclivity ( http://www.freesound.org/people/acclivity/  )
You can find this pack online at: http://www.freesound.org/people/acclivity/packs/1142/


License details
---------------

Sampling+: http://creativecommons.org/licenses/sampling+/1.0/
Creative Commons 0: http://creativecommons.org/publicdomain/zero/1.0/
Attribution: http://creativecommons.org/licenses/by/3.0/
Attribution Noncommercial: http://creativecommons.org/licenses/by-nc/3.0/


Sounds in this pack
-------------------

  * 18925__acclivity__ChimeBar_G6_ND.wav
    * url: http://www.freesound.org/people/acclivity/sounds/18925/
    * license: Attribution Noncommercial
  * 18924__acclivity__ChimeBar_G5_ND.wav
    * url: http://www.freesound.org/people/acclivity/sounds/18924/
    * license: Attribution Noncommercial
  * 18923__acclivity__ChimeBar_F6_ND.wav
    * url: http://www.freesound.org/people/acclivity/sounds/18923/
    * license: Attribution Noncommercial
  * 18922__acclivity__ChimeBar_F5_ND.wav
    * url: http://www.freesound.org/people/acclivity/sounds/18922/
    * license: Attribution Noncommercial
  * 18921__acclivity__ChimeBar_F_6_ND.wav
    * url: http://www.freesound.org/people/acclivity/sounds/18921/
    * license: Attribution Noncommercial
  * 18920__acclivity__ChimeBar_F_5_ND.wav
    * url: http://www.freesound.org/people/acclivity/sounds/18920/
    * license: Attribution Noncommercial
  * 18919__acclivity__ChimeBar_Eb6_ND.wav
    * url: http://www.freesound.org/people/acclivity/sounds/18919/
    * license: Attribution Noncommercial
  * 18918__acclivity__ChimeBar_Eb5_ND.wav
    * url: http://www.freesound.org/people/acclivity/sounds/18918/
    * license: Attribution Noncommercial
  * 18917__acclivity__ChimeBar_E6_ND.wav
    * url: http://www.freesound.org/people/acclivity/sounds/18917/
    * license: Attribution Noncommercial
  * 18916__acclivity__ChimeBar_E5_ND.wav
    * url: http://www.freesound.org/people/acclivity/sounds/18916/
    * license: Attribution Noncommercial
  * 18915__acclivity__ChimeBar_D6_ND.wav
    * url: http://www.freesound.org/people/acclivity/sounds/18915/
    * license: Attribution Noncommercial
  * 18914__acclivity__ChimeBar_D5_ND.wav
    * url: http://www.freesound.org/people/acclivity/sounds/18914/
    * license: Attribution Noncommercial
  * 18913__acclivity__ChimeBar_C6_ND.wav
    * url: http://www.freesound.org/people/acclivity/sounds/18913/
    * license: Attribution Noncommercial
  * 18912__acclivity__ChimeBar_C5_ND.wav
    * url: http://www.freesound.org/people/acclivity/sounds/18912/
    * license: Attribution Noncommercial
  * 18911__acclivity__ChimeBar_C_6_ND.wav
    * url: http://www.freesound.org/people/acclivity/sounds/18911/
    * license: Attribution Noncommercial
  * 18910__acclivity__ChimeBar_C_5_ND.wav
    * url: http://www.freesound.org/people/acclivity/sounds/18910/
    * license: Attribution Noncommercial
  * 18909__acclivity__ChimeBar_Bb5_ND.wav
    * url: http://www.freesound.org/people/acclivity/sounds/18909/
    * license: Attribution Noncommercial
  * 18908__acclivity__ChimeBar_B5_ND.wav
    * url: http://www.freesound.org/people/acclivity/sounds/18908/
    * license: Attribution Noncommercial
  * 18907__acclivity__ChimeBar_Ab5_ND.wav
    * url: http://www.freesound.org/people/acclivity/sounds/18907/
    * license: Attribution Noncommercial
  * 18906__acclivity__ChimeBar_A5_ND.wav
    * url: http://www.freesound.org/people/acclivity/sounds/18906/
    * license: Attribution Noncommercial

